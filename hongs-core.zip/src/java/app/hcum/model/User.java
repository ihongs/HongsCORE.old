package app.hcum.model;

import app.hongs.HongsException;
import app.hongs.action.ActionConfig;
import app.hongs.db.AbstractBaseModel;
import app.hongs.db.FetchMore;
import app.hongs.db.Table;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 用户基础信息模型
 * @author Hongs
 */
public class User
extends AbstractBaseModel {

    public User()
    throws HongsException {
        super("hcum", "a_hcum_user");
    }

    public Set<String> getGroups(String userId)
    throws HongsException {
        if (userId == null) throw new HongsException(0x10000, "User Id required!");

        Table asoc = this.db.getTable("a_hcum_user_group");
        FetchMore more = new FetchMore();
        more.select(".group_key")
            .where(".user_id = ?", userId);

        Set<String> groups = new HashSet();
        List<Map>   rows   = asoc.fetchMore(more);
        for (Map row : rows) {
            groups.add((String)row.get("group_key"));
        }

        return groups;
    }

    public static List getPageGroups(String name)
    throws HongsException {
        List pageGroups = new ArrayList();
        ActionConfig ac = new ActionConfig(name);

        Map<String, Map> pages1 = ac.pages;
        for (Map.Entry et1 : pages1.entrySet()) {
            Map page1 = (Map)et1.getValue();
            if (!page1.containsKey("pages")) {
                continue;
            }

            Map<String, Map> pages2 = (Map<String, Map>)page1.get("pages");
            for (Map.Entry et2 : pages2.entrySet()) {
                Map page2 = (Map)et2.getValue();
                if (!page2.containsKey("pages")) {
                    continue;
                }

            // 读取第2层的页面信息
            Map page_a = page2;
            Map page_b = new HashMap();
            List pages = new ArrayList();
            page_b.put("uri" , page_a.get("uri" ));
            page_b.put("name", page_a.get("name"));
            page_b.put("pages", pages);
            pageGroups.add(page_b);

                Map<String, Map> pages3 = (Map<String, Map>)page2.get("pages");
                for (Map.Entry et3 : pages3.entrySet()) {
                    Map page3 = (Map)et3.getValue();
                    if (!page3.containsKey("groups")) {
                        continue;
                    }

            // 读取第3层的页面信息
            Map page_c = page3;
            Map page_d = new HashMap();
            page_d.put("uri" , page_c.get("uri" ));
            page_d.put("name", page_c.get("name"));
            pages.add(page_d);

            // 读取页面分组信息
            List groups = new ArrayList();
            page_d.put("groups",  groups);
            Set<String> groupz = (Set)page_c.get("groups");
            for (String k : groupz) {
                Map group1 = ac.getGroup(k);
                Map group2 = new HashMap( );
                groups.add( group2 );
                group2.put("key" , group1.get("key" ));
                group2.put("name", group1.get("name"));
                group2.put("groups", ac.getAllGroups(k).keySet());
            }

                }
            }
        }

        return pageGroups;
    }

    @Override
    protected void getFilter(Map req, FetchMore more)
    throws HongsException {
        super.getFilter(req, more);

        /**
         * 如果有指定dept_id
         * 则关联a_hcum_user_detp来约束范围
         */
        if (req.containsKey("dept_id")) {
            more.join ("a_hcum_user_dept", ".user_id = :id")
                .where("dept_id = ?" , req.get( "dept_id" ));
        }
    }

    public String getAffectedNames() throws HongsException {
        StringBuilder sb = new StringBuilder();
        FetchMore     fm = new FetchMore();
        fm.setOption("FETCH_DFLAG", true );
        fm.select("name").where("id IN (?)", this.affectedIds);
        List<Map> rows = this.table.fetchMore(fm);
        for (Map  row  : rows) {
            sb.append(",").append(row.get("name").toString( ));
        }
        return sb.length()>0 ? sb.substring(1) : sb.toString();
    }

}
