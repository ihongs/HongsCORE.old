package app.common.cmdlet;

import app.hongs.cmdlet.annotation.Cmdlet;

/**
 * 定时任务管理器(未开发)
 * @author Hong
 */
@Cmdlet
public class task {
    
}
